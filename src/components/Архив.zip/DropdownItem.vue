<script setup lang="ts">

</script>

<template>
    <li class="up-menu-item relative">
        <slot />
    </li>
</template>

