<script setup lang="ts">

</script>

<template>
    <li>
        <div style="height: 1px;" class="bg-black opacity-40 dark:bg-white"></div>
    </li>
</template>
