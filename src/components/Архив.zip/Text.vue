<script setup lang="ts">

</script>

<template>
    <p class="text-gray-500 dark:text-white">
        <slot></slot>
    </p>
</template>
